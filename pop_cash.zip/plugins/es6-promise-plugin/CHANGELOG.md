# 4.2.2 / 2017-12-27

* updated to es6-promise 4.2.2
* added browser platform support

# 4.1.1 / 2017-09-12

* updated to es6-promise 4.1.1
* updated build script
