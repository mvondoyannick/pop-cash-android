import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrediterPage } from './crediter';

@NgModule({
  declarations: [
    CrediterPage,
  ],
  imports: [
    IonicPageModule.forChild(CrediterPage),
  ],
})
export class CrediterPageModule {}
